#include<QDebug>
#include <QtGui>

#include "delegate.h"

SpinBoxDelegate::SpinBoxDelegate(QObject *parent)
    : QItemDelegate(parent)
{
qDebug()<<"construct delegate";
}

QWidget *SpinBoxDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{
    QSpinBox *editor = new QSpinBox(parent);
    editor->setMinimum(0);
    editor->setMaximum(8);
    qDebug()<<"create Editor";
    return editor;
}

void SpinBoxDelegate::setEditorData(QWidget *editor,
                                    const QModelIndex &index) const
{
    int value = index.model()->data(index, Qt::DisplayRole).toInt();

    QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
    spinBox->setValue(value);
    qDebug()<<"set editor value= "<<value;
}

void SpinBoxDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                   const QModelIndex &index) const
{
    QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
    spinBox->interpretText();
    int value = spinBox->value();

    model->setData(index, value, Qt::EditRole);
    qDebug()<<"set model data";
}

void SpinBoxDelegate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    editor->setGeometry(option.rect);
    qDebug()<<"update geo";
}

// combobax delegate
comboDelegate::comboDelegate(QObject *parent)
    : QItemDelegate(parent)
{
}

QWidget *comboDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{
    QComboBox *editor = new QComboBox(parent);
    qDebug()<<"create editor";
        editor->addItems(listComBovalue);
    return editor;
}

void comboDelegate::setEditorData(QWidget *editor,
                                    const QModelIndex &index) const
{
    QVariant value = index.model()->data(index);
    qDebug()<<"set editor data";
    QComboBox *comboBox = static_cast<QComboBox*>(editor);
    int idex= comboBox->findData(value,Qt::DisplayRole,Qt::MatchExactly);
    comboBox->setCurrentIndex(idex);
}

void comboDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                   const QModelIndex &index) const
{
    qDebug()<<"set model";
    QComboBox *comBoBox = static_cast<QComboBox*>(editor);
    QVariant value =  comBoBox->itemData(comBoBox->currentIndex(),Qt::DisplayRole);
    qDebug()<<"value ="<<value;
    model->setData(index, value, Qt::EditRole);
   // MainDbCommonViewModel  *modelMessage=dynamic_cast<MainDbCommonViewModel*> model;
}

void comboDelegate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    qDebug()<<"set geo";
    editor->setGeometry(option.rect);
}

// checkbox delegate
checkboxDelegate::checkboxDelegate(QObject *parent)
    : QItemDelegate(parent)
{
}

QWidget *checkboxDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{
    QCheckBox *editor = new QCheckBox(parent);
    return editor;
}

void checkboxDelegate::setEditorData(QWidget *editor,
                                    const QModelIndex &index) const
{
    int value = index.model()->data(index, Qt::EditRole).toInt();
    QCheckBox *checkbox = static_cast<QCheckBox*>(editor);
   // int idex= checkbox->findData(value,Qt::UserRole,Qt::MatchExactly);
    //checkbox->setCurrentIndex(idex);
    checkbox->setChecked(value);
}

void checkboxDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                   const QModelIndex &index) const
{
    QCheckBox *checkbox = static_cast<QCheckBox*>(editor);
    //QVariant value =  checkbox->itemData(checkbox->currentIndex(),Qt::DisplayRole);
    QVariant value = checkbox->isChecked();
    model->setData(index, value, Qt::EditRole);
   // MainDbCommonViewModel  *modelMessage=dynamic_cast<MainDbCommonViewModel*> model;
}

void checkboxDelegate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    editor->setGeometry(option.rect);
}

// lineEdit delegate
lineEditDelegate::lineEditDelegate(QObject *parent)
    : QItemDelegate(parent)
{
}

QWidget *lineEditDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{
    QLineEdit *editor = new QLineEdit(parent);
    return editor;
}

void lineEditDelegate::setEditorData(QWidget *editor,
                                    const QModelIndex &index) const
{
    QString value = index.model()->data(index, Qt::EditRole).toString();
    QLineEdit *lineEdit = static_cast<QLineEdit*>(editor);
   // int idex= checkbox->findData(value,Qt::UserRole,Qt::MatchExactly);
    //checkbox->setCurrentIndex(idex);
    lineEdit->setText(value);

}

void lineEditDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                   const QModelIndex &index) const
{
    QLineEdit *lineEdit = static_cast<QLineEdit*>(editor);
    //QVariant value =  checkbox->itemData(checkbox->currentIndex(),Qt::DisplayRole);
    QVariant value = lineEdit->text();
    model->setData(index, value, Qt::EditRole);
   // MainDbCommonViewModel  *modelMessage=dynamic_cast<MainDbCommonViewModel*> model;
}

void lineEditDelegate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    editor->setGeometry(option.rect);
}
