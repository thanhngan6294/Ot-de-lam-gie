#include "delegatewidget.h"

DelegateWidget::DelegateWidget()
{
}
