#ifndef EDITTABLEWIDGET_H
#define EDITTABLEWIDGET_H
#include<QTableView>

class editTableWidget: public QTableView
{
public:
    editTableWidget(QWidget * parent = 0);
//    void removeRow(int row);
//    void doubleClicked();

};

#endif // EDITTABLEWIDGET_H
